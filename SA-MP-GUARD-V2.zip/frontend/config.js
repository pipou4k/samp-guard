// Set this to your Render backend URL, for example:
// window.GUARD_CONFIG = { API_BASE_URL: "https://your-service.onrender.com" };
window.GUARD_CONFIG = { API_BASE_URL: "" };