SA-MP GUARD V2 — DEPLOYMENT GUIDE

PROJECT LAYOUT
frontend/  -> deploy this folder to Netlify
backend/   -> deploy this folder/service to Render
No files' contents are uploaded. Only selected file metadata and local scan indicators are submitted when the player consents.

1) CREATE DATABASE
- Create a PostgreSQL database (Render PostgreSQL or another PostgreSQL provider).
- Open backend/schema.sql in the database SQL console and run it.
- PostgreSQL gen_random_uuid() is available in supported modern PostgreSQL versions.

2) DEPLOY BACKEND TO RENDER
- Push this project to a GitHub repository.
- In Render choose New > Web Service and connect the repository.
- Root Directory: backend
- Build Command: npm install
- Start Command: npm start
- Add environment variables:
  DATABASE_URL = your PostgreSQL internal/external connection string
  DATABASE_SSL = true (if provider requires SSL)
  ADMIN_ACCESS_CODE = choose a long unique secret; do not share it
  SESSION_SECRET = at least 32 random characters
  ALLOWED_ORIGINS = https://YOUR-SITE.netlify.app
- Deploy. Test https://YOUR-RENDER-SERVICE.onrender.com/api/health

3) DEPLOY FRONTEND TO NETLIFY
- Create a Netlify site from the same GitHub repository.
- Base directory: frontend
- Publish directory: .
- After deploy, edit frontend/config.js:
  window.GUARD_CONFIG = { API_BASE_URL: "https://YOUR-RENDER-SERVICE.onrender.com" };
- Commit and redeploy.
- Set backend ALLOWED_ORIGINS to the exact Netlify site URL (no trailing slash), then redeploy backend.

4) TEST
- Open the Netlify URL.
- Select PC or Mobile.
- Tick consent; click Browse files; select harmless test files.
- Run scan. A report should be stored in PostgreSQL.
- Click Admin access; enter ADMIN_ACCESS_CODE from Render environment variables.
- Dashboard lists report summaries.

IMPORTANT
- Admin code is checked server-side; never put it in config.js or frontend source.
- Admin reports list metadata and indicators only. Raw files and file contents are not uploaded.
- Browser file pickers only expose user-selected files. A website cannot get full-device file access like a privileged native app.
- The current scan rules are basic heuristic indicators and can produce false positives/false negatives. They are not a definitive cheat detector.
- Do not ban a player solely because of a filename, extension, or one heuristic match.
- The advanced PC option in a future phase should be a separately signed, transparent desktop scanner with narrow permissions and explicit consent. Mobile scanning remains limited by Android/iOS sandbox rules.
- Render free services may sleep; first request can be delayed. Free database retention/availability depends on current provider terms; use a suitable persistent database plan for production.
