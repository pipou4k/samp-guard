CREATE TABLE IF NOT EXISTS scan_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  device VARCHAR(16) NOT NULL CHECK (device IN ('PC','Mobile')),
  total_files INTEGER NOT NULL CHECK (total_files BETWEEN 1 AND 100),
  flagged_files INTEGER NOT NULL CHECK (flagged_files BETWEEN 0 AND 100),
  files JSONB NOT NULL,
  findings JSONB NOT NULL DEFAULT '[]'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS scan_reports_created_at_idx ON scan_reports(created_at DESC);