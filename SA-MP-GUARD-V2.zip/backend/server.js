import express from "express";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import pg from "pg";
import crypto from "node:crypto";

const { Pool } = pg;
const app = express();
app.set("trust proxy", 1);
app.use(helmet());
const allowed = (process.env.ALLOWED_ORIGINS || "").split(",").map(x=>x.trim()).filter(Boolean);
app.use(cors({origin:(origin,cb)=>{if(!origin || allowed.length===0 || allowed.includes(origin)) return cb(null,true); cb(new Error("Origin not allowed"));}}));
app.use(express.json({limit:"100kb"}));
const pool = process.env.DATABASE_URL ? new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_SSL==="false"?false:{rejectUnauthorized:false}}) : null;
const loginLimiter=rateLimit({windowMs:15*60*1000,limit:8,standardHeaders:true,legacyHeaders:false});
const reportLimiter=rateLimit({windowMs:60*60*1000,limit:20,standardHeaders:true,legacyHeaders:false});
const b64=b=>Buffer.from(b).toString("base64url");
function sign(payload){const body=b64(JSON.stringify(payload));const sig=crypto.createHmac("sha256",process.env.SESSION_SECRET).update(body).digest("base64url");return body+"."+sig}
function verify(token){try{const [body,sig]=token.split(".");const expected=crypto.createHmac("sha256",process.env.SESSION_SECRET).update(body).digest();const actual=Buffer.from(sig,"base64url");if(actual.length!==expected.length||!crypto.timingSafeEqual(actual,expected))return null;const p=JSON.parse(Buffer.from(body,"base64url").toString());return p.exp>Date.now()/1000?p:null}catch{return null}}
function admin(req,res,next){const h=req.headers.authorization||"";const token=h.startsWith("Bearer ")?h.slice(7):"";const p=verify(token);if(!p?.admin){return res.status(401).json({error:"Admin authentication required"})}next()}
function validReport(x){return x&&x.consent===true&&["PC","Mobile"].includes(x.device)&&Array.isArray(x.files)&&x.files.length>0&&x.files.length<=100&&Array.isArray(x.findings)&&x.findings.length<=100}
app.get("/api/health",(req,res)=>res.json({ok:true,service:"SA-MP GUARD API",version:"2.0.0",database:!!pool}));
app.post("/api/reports",reportLimiter,async(req,res)=>{try{if(!pool)return res.status(503).json({error:"Reports database is not configured yet"});const x=req.body;if(!validReport(x))return res.status(400).json({error:"Invalid report or consent missing"});const files=x.files.map(f=>({name:String(f.name||"").slice(0,180),size:Math.max(0,Math.min(Number(f.size)||0,2**40)),type:String(f.type||"unknown").slice(0,20)}));const findings=x.findings.map(f=>({name:String(f.name||"").slice(0,180),size:Math.max(0,Math.min(Number(f.size)||0,2**40)),type:String(f.type||"unknown").slice(0,20),reasons:Array.isArray(f.reasons)?f.reasons.slice(0,10).map(v=>String(v).slice(0,180)):[]}));const result=await pool.query("INSERT INTO scan_reports(device,total_files,flagged_files,files,findings) VALUES($1,$2,$3,$4,$5) RETURNING id,created_at",[x.device,files.length,findings.length,JSON.stringify(files),JSON.stringify(findings)]);res.status(201).json({ok:true,id:result.rows[0].id,createdAt:result.rows[0].created_at})}catch(e){console.error("report error",e.message);res.status(500).json({error:"Could not save report"})}});
app.post("/api/admin/login",loginLimiter,(req,res)=>{const code=String(req.body?.code||"");const expected=String(process.env.ADMIN_ACCESS_CODE||"");if(!expected||!process.env.SESSION_SECRET)return res.status(503).json({error:"Admin authentication is not configured"});const a=crypto.createHash("sha256").update(code).digest();const b=crypto.createHash("sha256").update(expected).digest();if(!crypto.timingSafeEqual(a,b))return res.status(401).json({error:"Incorrect access code"});const token=sign({admin:true,exp:Math.floor(Date.now()/1000)+60*60});res.json({ok:true,token,expiresIn:3600})});
app.get("/api/admin/reports",admin,async(req,res)=>{try{if(!pool)return res.status(503).json({error:"Database unavailable"});const q=await pool.query("SELECT id,device,total_files,flagged_files,created_at FROM scan_reports ORDER BY created_at DESC LIMIT 200");res.json({reports:q.rows})}catch(e){console.error("admin reports error",e.message);res.status(500).json({error:"Could not load reports"})}});
app.use((err,req,res,next)=>{if(err.message==="Origin not allowed")return res.status(403).json({error:"Origin not allowed"});console.error(err.message);res.status(500).json({error:"Server error"})});
const port=process.env.PORT||3000;app.listen(port,()=>console.log(`SA-MP GUARD API listening on ${port}`));
